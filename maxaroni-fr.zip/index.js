const djs = require('discord.js');
const bot = new djs.Client({
  intents: [
    "GUILDS",
    "GUILD_MESSAGES"
  ]
});
const config = process.env;
 
bot.on('ready', () => {
  console.log(bot.user.username + 'is online.')
});


 
bot.on('messageCreate', (msg) => {
  if(msg.author.bot || msg.channel.type === "dm")
  return;
  const messageArray = msg.content.split(' ');
  const cmd = messageArray[0];
  const args = msg.content.substring(msg.content.indexOf(' ') + 1);
  const prefix = config.prefix;
 
if(cmd === prefix + 'ping' ) {
msg.channel.send({
  content: 'pong!'
})
}
  if(cmd === prefix + 'status' ) {
msg.channel.send({
  content: 'online!'
})
}
  if(cmd === prefix + 'version' ) {
msg.channel.send({
  content: '1.0.0!'
})
}
  if(cmd === prefix + 'server' ) {
msg.channel.send({
  content: 'https://discord.gg/qsYgV5WM'
})
    
}
  if(cmd === prefix + 'hello' ) {
    msg.channel.send({
      content: ('Hello!')
    })
  }
   if(cmd === prefix + 'maxaroni' ) {
    msg.channel.send({
      content: ('Maxaroni#0476')
    })
  }
  

});
 
bot.login(config.token);